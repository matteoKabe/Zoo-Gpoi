<style>

/* Stile per la pagina di inserimento recensione */
body {
    font-family: Arial, sans-serif;
    background-color: #F5F5F5;
}

form {
    background-color: #FFFFFF;
    border-radius: 5px;
    padding: 20px;
    margin: 20px auto;
    max-width: 600px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

label {
    display: block;
    margin-bottom: 10px;
    font-size: 18px;
    font-weight: bold;
}

select, input[type="text"] {
    border: 1px solid #ccc;
    border-radius: 3px;
    padding: 5px;
    font-size: 16px;
    margin-bottom: 20px;
    width: 100%;
    box-sizing: border-box;
}

input[type="submit"] {
    background-color: #4CAF50;
    border: none;
    color: #FFFFFF;
    padding: 12px 20px;
    text-decoration: none;
    font-size: 18px;
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #3e8e41;
}

.successo {
    color: green;
    font-size: 40px;
    font-weight: bold;
    margin-top: 20%;
}

body{
  margin: 50px auto;
  width: 80%;
  max-width: 600px;
  text-align: center;
  border: 20px solid green;
  padding: 20px;
  border-radius: 10px;
}

.back{
  position: fixed;
  right: 30px;
  text-decoration: none;
  background-color: black;
  color: white;
  padding: 10px 5px;
  border-radius: 5px;
  bottom: 10px;
}

textarea{
	border: 1px solid #ccc;
    border-radius: 3px;
    padding: 5px;
    font-size: 16px;
    margin-bottom: 20px;
    width: 100%;
    box-sizing: border-box;
	height: 60%;
	resize: none;
}

a{
  background-color: #4CAF50;
  border: none;
  color: #FFFFFF;
  padding: 12px 20px;
  text-decoration: none;
  font-size: 18px;
  font-weight: bold;
  border-radius: 5px;
  cursor: pointer;
}

a:hover {
    background-color: #3e8e41;
}


</style>
<?php
    session_start();
    if(!isSet($_SESSION["user"])){
    	header("location: login.php?err=2");
    	die();
    }

    if(isset($_REQUEST['submit'])){
        $conn  = new  mysqli("127.0.0.1","root","","zoo")or die("errore");
        $valutazione = $_POST['star'];
        $commento = $_POST['commento'];
        $mail = $_SESSION['mail'];
        $get_person = mysqli_query($conn, "SELECT * FROM Persona WHERE mail='".$mail."'");
        $person = mysqli_fetch_array($get_person);
        $cod_persona = $person['cod_persona'];
        $cod_struttura = $_POST['cod_struttura'];
        $insert_review = mysqli_query($conn, "insert INTO recensione (cod_struttura, valutazione, commento, cod_persona)
                                               VALUES ('".$cod_struttura."','".$valutazione."','".$commento."','".$cod_persona."')");
        if($insert_review){
            echo "<p class='successo'>Recensione inserita con successo!</p></br>";
            echo "<a href='zoo_cliente.php'>torna alla home</a>";
        } else{
            echo "Errore nell'inserimento della recensione.";
        }
    }else{
?>
<body>
    <form method="POST" action="">
        <input type="hidden" name="cod_struttura" value="<?php echo $_REQUEST['cod_struttura']; ?>" required>
        <label for="star">Valutazione:</label>
        <select name="star" id="star">
            <option value="1">1 stella</option>
            <option value="2">2 stelle</option>
            <option value="3">3 stelle</option>
            <option value="4">4 stelle</option>
            <option value="5">5 stelle</option>
        </select>
        <br>
        <label for="commento">Commento:</label>
		<textarea id="commento" name="commento" rows="4" cols="50" placeholder='inserisci un commento'></textarea>
        <br>
        <input type="submit" name="submit" value="Inserisci recensione">
    </form>
    <a href=zoo_cliente.php class=back>Back</a>
</body>
<?php
}
?>
