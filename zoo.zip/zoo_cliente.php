<?php
session_start();
session_destroy();
$_SESSION["user"]="Matteo";
?>
<style>

body{
  background-color: white;
}

.sfondoNome{
  width: 1559px;
  height: 600px;
  position: absolute;
}

.strappo_header{
  width: 1559px;
  height: 50px;
  margin-top: 550px;
  position:  absolute;
}

.esci{
  width: 70px;;
  position: absolute;
  border-radius: 50%;
  margin-top: 30px;
  margin-left: 1459px;
}

.nome_utente{
  position: absolute;
  color: white;
  margin-top: 40px;;
  text-align: right;
  right: 150px;
  font-size: 40px;
}

.zoo{
  transform: rotate(-20deg);
  font-size: 100px;
  color: white;
  margin-left: 40px;
}

.Nomezoo{
  transform: rotate(-20deg);
  margin-left: 200px;
  font-size: 100px;
  margin-top: -60px;
  color: orange;
}

.descrizione{
  margin-top: 400px;
  text-align: center;
  font-size: 30px;
}

.mappa{
  width: 600px;
  position: absolute;
  z-index: -1;
  margin-left: 959px;
  margin-top: 20px;
}

.strappo_mappa_alt{
  width: 600px;
  margin-left: 959px;
  position: absolute;
  margin-top: 20px;
}

.strappo_mappa_bas{
  width: 600px;
  margin-left: 959px;
  position: absolute;
  margin-top: 400px;
}

.strappo_mappa_dx{
  position: absolute;
  height: 400px;
  margin-top: 20px;
  margin-left: 1537px;
}

.strappo_mappa_sx{
  position: absolute;
  margin-left: 959px;
  height: 400px;
  margin-top: 20px;
}

.pink{
  margin-top: 300px;
}

.orario{
  margin-top: 100px;
  text-align: center;
  margin-right: 600px;
  font-size: 30px;
}

.compra{
  background-color: black;
  color: white;
  padding: 50px 100px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  border-style: double;
  margin-top: 50px;
  margin-left: 300px;
  font-size: 30px;
  border-radius: 50px;
}

.compra:hover{
  background-color: white;
  color: black;
  transition: 0.5s;
}

.negozi{
  background-color: black;
  color: white;
  padding: 50px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  border-style: double;
  margin-top: 150px;
  margin-left: 50px;
  width: 650px;
  font-size: 50px;
  border-radius: 50px;
}

.negozi:hover{
  background-color: white;
  color: black;
  transition: 0.5s;
}

.ristoranti{
  background-color: black;
  color: white;
  padding: 50px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  border-style: double;
  margin-top: 150px;
  margin-left: 50px;
  width: 650px;
  font-size: 50px;
  border-radius: 50px;
}

.ristoranti:hover{
  background-color: white;
  color: black;
  transition: 0.5s;
}

.pink{
  position: absolute;
  margin-left: -1515px;
  width: 1559px;
  z-index: -1;
  margin-top: 400px;
  height: 500px;
}

.pr_pink{
  position: absolute;
  font-size: 100px;
  margin-left: 100px;
  margin-top: 250px;
  transform: rotate(-10deg);
  color: pink;
  text-shadow: -5px -5px black;
}

.strappo_pink_alto{
  position: absolute;
  margin-top: 400px;
  margin-left: -1515px;
  width: 1559px;
}

.strappo_pink_basso{
  position: absolute;
  margin-top: 850px;
  margin-left: -1515px;
  width: 1559px;
}

.strappo_pink_sx{
  position: absolute;
  height: 500px;
  margin-left: -1515px;
  margin-top: 400px;
}

.strappo_pink_dx{
  position: absolute;
  height: 500px;
  margin-top: 400px;
  margin-left: 16px;
}

.lista_animali{
  position: absolute;
  margin-top: 700px;
  font-size: 100px;
  font-weight: bold;
  margin-left: 420px;
  background-color: black;
  padding: 50px;
  border-radius: 50px;
  color: white;
}

.animali{
  margin-top: 1000px;
  width: 1559px;
}

.animali td {
  text-align: center;
  vertical-align: middle;
  padding-bottom: 50px;
}

.animali td img{
  border-radius: 20px;
  width: 400px;
  height: 400px;
}

.animali .razza{
  position: absolute;
  font-size: 50px;
  margin-left: 200px;
  background-color: white;
  padding: 10px;
  border-radius: 5px;
  margin-top: -50px;
}

</style>
<body background="yellow">
  <img src="foto/sfondoNome.png" class="sfondoNome" alt="Mia Immagine">
  <h3 class="nome_utente"><?php echo $_SESSION["user"]; ?></h3>
  <a href="esci.php"> <img src="foto/esci.png" class="esci" alt="Mia Immagine"> </a>
  <img src="foto/strappo_basso.png" class="strappo_header" alt="Mia Immagine">
  <h1 class="zoo"> Benvenuti allo</h1>
  <h1 class="NomeZoo"> ZOO 105</h1>
  <p class="descrizione"> Il nostro Zoo offre un'esperienza <b>unica e avvincente</b> per <b>tutta la famiglia</b>.</br> Con moltissime specie esotiche e famose lo Zoo è un luogo <b>perfetto</b> per osservare la <b>meraviglia della natura</b>.</br> Scopri la <b>bellezza</b> e la diversità degli animali.</br> Non perdere l'opportunità di creare <b>memorie indimenticabili</b> con i tuoi cari.</br><b> Vieni a trovarci! </b></p>
  <img src="foto/mappa.png" class="mappa">
  <img src="foto/strappo_alto.png" class="strappo_mappa_alt" alt="Mia Immagine">
  <img src="foto/strappo_sx.png" class="strappo_mappa_sx" alt="Mia Immagine">
  <img src="foto/strappo_dx.png" class="strappo_mappa_dx" alt="Mia Immagine">
  <img src="foto/strappo_basso.png" class="strappo_mappa_bas" alt="Mia Immagine">
  <p class="orario"> APERTO <b>TUTTI</b> I GIORNI (festivi compresi) </br> dalle h <b>09.00</b> alle h <b>17.00</b> (uscita h <b>19.00</b>) </p>
  <a href="compra.php" class="compra"> compra biglietti </a> </br>
  <a href="negozi.php" class="negozi"> negozi </a>
  <a href="ristoranti.php" class="ristoranti"> ristoranti </a>
  <img src="foto/pink.png" class="pink" alt="Mia Immagine">
  <p class="pr_pink"><b> La nostra star </br> P!NK !!! </b></p>
  <img src="foto/strappo_alto.png" class="strappo_pink_alto" alt="Mia Immagine">
  <img src="foto/strappo_basso.png" class="strappo_pink_basso" alt="Mia Immagine">
  <img src="foto/strappo_sx.png" class="strappo_pink_sx" alt="Mia Immagine">
  <img src="foto/strappo_dx.png" class="strappo_pink_dx" alt="Mia Immagine">
  <p class="lista_animali"> i nostri animali </p>
  <table class="animali">
    <tr>
      <td>
        <a href="razza.php?razza=leone"> <img src="foto/leone.png" alt="Mia Immagine"> </a>
        <p class="razza">leone</p>
      </td>
      <td>
        <a href="razza.php?razza=leone"> <img src="foto/leone.png" alt="Mia Immagine"> </a>
        <p class="razza">leone</p>
      </td>
      <td>
        <a href="razza.php?razza=leone"> <img src="foto/leone.png" alt="Mia Immagine"> </a>
        <p class="razza">leone</p>
      </td>
    </tr>
    <tr>
      <td>
        <a href="razza.php?razza=leone"> <img src="foto/leone.png" alt="Mia Immagine"> </a>
        <p class="razza">leone</p>
      </td>
      <td>
        <a href="razza.php?razza=leone"> <img src="foto/leone.png" alt="Mia Immagine"> </a>
        <p class="razza">leone</p>
      </td>
      <td>
        <a href="razza.php?razza=leone"> <img src="foto/leone.png" alt="Mia Immagine"> </a>
        <p class="razza">leone</p>
      </td>
    </tr>
  </table>
</body>
