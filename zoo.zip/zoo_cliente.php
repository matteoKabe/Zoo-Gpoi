<?php
    session_start();
    if(!isSet($_SESSION["user"])){
    	header("location: login.php?err=2");
    	die();
    }
?>
<style>

body{
  background-color: white;
}

a{
	text-transform: capitalize;
}

.sfondoNome{
  width: 100%;
  height: 90%;
  display: block;
  z-index: -1;
}

.esci{
  width: 5%;
  position: absolute;
  border-radius: 50%;
  top: 5%;
  right: 2%;
}

.nome_utente{
  position: absolute;
  color: white;
  top: 2%;
  text-align: right;
  right: 8%;
  font-size: 200%; /*non funziona*/
}

.descrizione{
  margin-top: 50px;
  text-align: center;
  font-size: 40px;
  display: block;
}

.compra{
  background-color: black;
  color: white;
  padding: 50px 25px;
  text-decoration: none;
  border-style: double;
  font-size: 50px;
  border-radius: 50px;
  float: left;
  margin-left: 10%;
  margin-right: 5%;
  margin-top: 50px;
}

.compra:hover{
  background-color: white;
  color: black;
  transition: 0.5s;
}

.orario{
  font-size: 30px;
  margin-top: 80px;
  text-align: center;
}

.mappa{
  width: 40%;
  margin-top: 10%;
  display: block;
  margin-left: 30%;
  margin-bottom: 5%;
}

.negozi{
  background-color: black;
  color: white;
  padding: 50px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  border-style: double;
  margin-left: 5%;
  width: 40%;
  font-size: 50px;
  border-radius: 50px;
}

.negozi:hover{
  background-color: white;
  color: black;
  transition: 0.5s;
}

.ristoranti{
  background-color: black;
  color: white;
  padding: 50px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  border-style: double;
  margin-left: 5%;
  width: 40%;
  font-size: 50px;
  border-radius: 50px;
}

.ristoranti:hover{
  background-color: white;
  color: black;
  transition: 0.5s;
}

a{
  text-decoration: none;
}

.pink{
  width: 100%;
  z-index: -1;
  margin-top: 5%;;
  height: 90%;
}

.pr_pink{
  font-size: 100px;
  margin-left: 100px;
  margin-top: 350px;
  transform: rotate(-10deg);
  color: pink;
  text-shadow: -5px -5px black;
  min-width: 500px;
}

.lista_animali{
  margin-top: 5%;
  font-size: 80px;
  font-weight: bold;
  background-color: dimgray;
  padding: 50px;
  border-radius: 50px;
  color: white;
  text-align: center;
  text-transform: capitalize;
  margin-left: 20%;
  margin-right: 20%;
}

.animali{
  background-color: dimgray;
  margin-top: -120px;
  padding: 50px;
  border-radius: 50px;
}

.animale{
  width: 30%;
  height: 50%;
  margin: 1.5%;
  border-radius: 50px;
}

a:hover img{
  opacity: 0.5;
  transition: 0.5s;
}

</style>

<body>
  <img src="foto/sfondoNome.jpg" class="sfondoNome" alt="Mia Immagine">
  <h3 class="nome_utente"><?php echo $_SESSION["user"]; ?></h3>
  <a href="esci.php"><img src="foto/esci.png" class="esci" alt="Mia Immagine"></a>
  <p class="descrizione"> Il nostro Zoo offre un'esperienza <b>unica e avvincente</b> per <b>tutta la famiglia</b>.<br>Con moltissime specie esotiche e famose, lo Zoo è un luogo <b>perfetto</b> per osservare la <b>meraviglia della natura</b>.<br>Scopri la <b>bellezza</b> e la diversità degli animali.<br>Non perdere l'opportunità di creare <b>memorie indimenticabili</b> con i tuoi cari.<br><b>Vieni a trovarci!</b></p>
  <a href="compra.php" class="compra">compra biglietti</a><br>
  <p class="orario">APERTO <b>TUTTI</b> I GIORNI (festivi compresi)<br>dalle h <b>09.00</b> alle h <b>17.00</b> (uscita h <b>19.00</b>)</p>
  <img src="foto/mappa.jpg" class="mappa">
  <a href="negozi.php" class="negozi">negozi</a>
  <a href="ristoranti.php" class="ristoranti">ristoranti</a>
  <a href="pink.php"><img src="foto/pink.jpg" class="pink" alt="Mia Immagine"></a>
  <?php
  $conn = new mysqli("127.0.0.1", "root", "", "zoo") or die("errore");
  //da errore quando non trova un utente
  $query = "select * from specie";
  $count = 0;
  $ris = $conn->query($query);
  if ($ris->num_rows > 0) {
    echo "<p class='lista_animali'>i nostri animali</p>";
    echo "<div class='animali'>";
    while ($ret = $ris->fetch_assoc()) {
      $count++;
      echo "<a href='razza.php?razza=" . $ret["nome_specie"] . "'><img src='foto/animali/". $ret["nome_specie"] . ".jpg' class='animale' alt='".$ret["nome_specie"]."'></a>";
    }
    echo "</div>";
  }
  ?>
</body>
