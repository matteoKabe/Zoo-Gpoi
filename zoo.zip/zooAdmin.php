<?php
    session_start();
    if(!isSet($_SESSION["user"])){
    	header("location: login.php?err=2");
    	die();
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <?php

        if(isset($_REQUEST['err'])){
            switch ($_REQUEST['err']) {
                case '1':
                    echo "<p class=fatto>dipendente aggiunto</p>";
                    break;
                case '2':
                    echo "<p class=errore>email gia utilizzata</p>";
                    break;
                case '3':
                    echo "<p class=fatto>animale aggiunto</p>";
                    break;
                case '4':
                    echo "<p class=fatto>dipendente licenziato GODO</p>";
                    break;
                case '5':
                    echo "<p class=errore>Esiste già un animale con quel nome</p>";
                    break;
                case '6':
                    echo "<p class=fatto>Famiglia aggiunta correttamente</p>";
                    break;
                case '7':
                    echo "<p class=errore>Esiste già una Famiglia con quel nome</p>";
                    break;
                case '8':
                    echo "<p class=errore>Esiste già una Specie con quel nome</p>";
                    break;
                case '9':
                    echo "<p class=fatto>Specie aggiunta correttamente</p>";
                    break;
                case '10':
                    echo "<p class=errore>L'utente è nella lista della vergogna</p>";
                    break;
                case '10':
                    echo "<p class=errore>Il file non è un immagine .jpg</p>";
                    break;
                default:
                    echo "<p class=errore>errore</p>";
                    break;
            }
        }

        $conn = new mysqli("127.0.0.1", "root", "", "Zoo");
        if ($conn->connect_errno) {
             echo $conn->connect_errno;
             die();
        }
    ?>
</head>
<body>
    <h1>Benvenuto Admin</h1>
    <h3>Aggiungi un dipendente: </h3>
    <form action=addDipendente.php method=post>
        <div>
            <label for=nome>Inserisci il nome: </label>
            <input type=text name="nome" id="nome" placeholder="Nome" required />
            <label for=nomignolo>Inserisci il nomignolo: </label>
            <input type=text name="nomignolo" id="nomignolo" placeholder="Nomignolo" required />
            <label for=cognome>Inserisci il cognome: </label>
            <input type=text name="cognome" id="cognome" placeholder="Cognome" required />
            <label for=ferie>Inserisci le ferie: </label>
            <input type=date name="ferie" id="ferie" placeholder="Ferie" required />
            <label for=nascita>Inserisci la data di nascita: </label>
            <input type=date name="nascita" id="nascita" placeholder="Data di nascita" required />
        </div>
        <div>
            <label for="mansione">Seleziona la mansione </label>
            <select name=mansione id=mansione>
                <option value=0>Cassiere</option>
                <option value=1>Curatore</option>
                <option value=2>Venditore</option>
            </select>
            <label for="strutt">Se devi aggiungere un venditore, selezione il codice della struttura dove lavora:</label>
            <select name="strutt" id="strutt">
                 <?php
                    $conn = new mysqli("127.0.0.1", "root", "", "Zoo");
                    if ($conn->connect_errno) {
                        echo $conn->connect_errno;
                        die();
                    }

                    $query = "SELECT cod_struttura FROM strutture;";
                    $ris = $conn->query($query);
                    while ($row = $ris->fetch_assoc()) {
                        foreach ($row as $key => $value) {
                            echo "<option value=$value>$value</option>";
                        }
                    }
                ?>
            </select>
            <label for=email>Inserisci l'email: </label>
            <input type=email name="email" id="email" placeholder="Email" required />
            <label for=password>Inserisci la password: </label>
            <input type=password name="password" id="password" placeholder="Password" required />
        </div>
        <div>
            <input type="submit" name="invia" />
        </div>
    </form>

    <h3>Aggiungi un animale: </h3>
    <form action=addAnimale.php method=post>
        <div>
            <label for=nome>Inserisci il nome: </label>
            <input type=text name="nome" id="nome" placeholder="Nome" required />
            <label for=peso>Inserisci il peso: </label>
            <input type=number name="peso" id="peso" placeholder="Peso" required />
            <label for=eta>Inserisci l'età: </label>
            <input type=number name="eta" id="eta" placeholder="Età" required />
            <label for=specie>Inserisci la Specie: </label>
            <select name="specie" id="specie">
                <?php
                    $conn = new mysqli("127.0.0.1", "root", "", "Zoo");
                    if ($conn->connect_errno) {
                        echo $conn->connect_errno;
                        die();
                    }

                    $query = "SELECT nome_specie FROM specie;";
                    $ris = $conn->query($query);
                    while ($row = $ris->fetch_assoc()) {
                        foreach ($row as $key => $value) {
                            echo "<option value=$value>$value</option>";
                        }
                    }
                ?>
            </select>
            <label for=musica>Inserisci il genere musicale preferito: </label>
            <select name=musica id=musica>
                <option value="Pop">Pop</option>
                <option value="Rock">Rock</option>
                <option value="Hip-Hop/Rap">Hip-Hop/Rap</option>
                <option value="Dance/Elettronica">Dance/Elettronica</option>
                <option value="Latina">Latina</option>
                <option value="Classica">Classica</option>
                <option value="R&B">R&B</option>
                <option value="Country">Country</option>
                <option value="Reggae">Reggae</option>
                <option value="Soundtrack">Soundtrack</option>
            </select>
        </div>
        <div>
            <input type="submit" name="invia" />
        </div>
    </form>

    <h3>Aggiungi una nuova famiglia: </h3>
    <form action=addFamiglia.php method=post>
        <div>
            <label for="nome_f">Qual è il nome della famiglia?</label>
            <input type="text" id="nome_f" name="nome_f" placeholder="Nome Famiglia" required />
        </div>
        <div>
            <input type=submit name=invia />
        </div>
    </form>

    <h3>Aggiungi una nuova specie: </h3>
    <form action=addSpecie.php method=post enctype="multipart/form-data">
        <div>
            <label for="nome_sp">Qual è il nome della specie?</label>
            <input type="text" id="nome_sp" name="nome_sp" placeholder="Nome Specie" required />
            <label for="nomeFam">Seleziona di quale famiglia fa parte:</label>
            <select name="nomeFam" id="nomeFam">
                 <?php
                    $conn = new mysqli("127.0.0.1", "root", "", "Zoo");
                    if ($conn->connect_errno) {
                        echo $conn->connect_errno;
                        die();
                    }

                    $query = "SELECT nomeFamiglia FROM famiglia;";
                    $ris = $conn->query($query);
                    while ($row = $ris->fetch_assoc()) {
                        foreach ($row as $key => $value) {
                            echo "<option value=$value>$value</option>";
                        }
                    }

                ?>
            </select>
            <label for=immagine>Inserisci l'immagine (nome Specie.jpg): </label>
      			<input type="file" name="fileToUpload" id="fileToUpload">
        </div>
        <div>
            <input type=submit name=invia />
        </div>
    </form>

    <h3>Licenzia un dipendente: </h3>
    <form action=licenzia.php method=post>
        <div>
            <label for=dip>Seleziona dipendente: </label>
            <select name=dip id=dip>
                <?php
                    $query = "SELECT nomignolo FROM dipendenti WHERE orario_lavorativo<40;";
                    $ris = $conn->query($query);
                    while ($row = $ris->fetch_assoc()) {
                        foreach ($row as $key => $value) {
                            echo "<option value=$value>$value</option>";
                        }
                    }
                ?>
            </select>
        </div>
        <div>
            <input type="submit" name="invia" />
        </div>
    </form>
  </br>
    <a href=esci.php>Esci</a>
  </br>
</body>
<style>
body {
  background-color: #f2f2f2;
  font-family: Arial, sans-serif;
}

.fatto{
  text-align: center;
  color: green;
}

.errore{
  text-align: center;
  color: red;
}

a{
  position: fixed;
  right: 30px;
  text-decoration: none;
  background-color: black;
  color: white;
  padding: 10px 5px;
  border-radius: 5px;
  bottom: 10px;
}

h1 {
  font-size: 36px;
  text-align: center;
}

h3 {
  font-size: 24px;
  margin-top: 40px;
}

form {
  margin-top: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
  font-size: 18px;
}

input[type="file"] {
  font-size: 1.2em;
  color: #444;
  background-color: #f7f7f7;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
  outline: none;
  box-shadow: none;
  margin-bottom: 10px;
}

input[type="file"]:hover,
input[type="file"]:focus {
  border-color: #4CAF50;
  box-shadow: 0 0 4px #4CAF50;
}

input[type="file"]::-webkit-file-upload-button {
  background-color: #4CAF50;
  color: white;
  border-radius: 4px;
  padding: 8px 12px;
  border: none;
  font-weight: bold;
  text-transform: uppercase;
  cursor: pointer;
}


input[type="text"],
input[type="date"],
input[type="number"],
input[type="email"],
input[type="password"],
select {
  width: 100%;
  padding: 12px;
  margin-bottom: 20px;
  border: none;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type="submit"] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type="submit"]:hover {
  background-color: #45a049;
}

select {
  height: 40px;
}

option {
  font-size: 16px;
}

</style>
</html>
