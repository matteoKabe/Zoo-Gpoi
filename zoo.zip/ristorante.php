<?php
session_start();
if(!isSet($_SESSION["user"])){
	header("location: login.php?err=2");
	die();
}
?>
<style>

body {
  font-family: Arial, sans-serif;
  background-color: tan;
  text-align: center;
  text-transform: capitalize;
}

.nome_rist {
  font-size: 40px;
  font-weight: bold;
  margin-top: 50px;
}

img {
  margin: 30px 0;
  border-radius: 5%;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  width: 30%;
}

.orario_ris {
  font-size: 24px;
  margin-bottom: 30px;
}

.menu {
  font-size: 35px;
  margin-top: 50px;
  margin-bottom: 30px;
}

.nome_piatto {
  font-size: 30px;
  font-weight: bold;
  margin-bottom: 10px;
}

.prezzo {
  font-size: 30px;
  margin-bottom: 30px;
}

.prezzo::after {
  content: ".00 €";
}

p {
  margin: 0;
}

.err{
  color: red;
}

.recensione{
  background-color: brown;
  color: tan;
  padding: 10px 5px;
  text-decoration: none;
  font-size: 15px;
  border-radius: 5px;
  margin-top: 50px;
}

.recensione:hover{
  background-color: tan;
  color: brown;
  transition: 0.5s;
  border: solid 2px brown;
}

.back{
  position: fixed;
  right: 30px;
  text-decoration: none;
  background-color: black;
  color: white;
  padding: 10px 5px;
  border-radius: 5px;
  bottom: 10px;
}

</style>
<body>
<?php
    $conn  = new  mysqli("127.0.0.1","root","","zoo")or die("errore");
    //da errore quando non  trova un utente
    $query ="select * from ristoranti where cod_struttura=".$_REQUEST["cod"];
    $ris = $conn->query($query);
    $ret = $ris -> fetch_assoc();
    echo "<h1 class='nome_rist'>".$ret['nome_ristorante']."</h1>";
    /* non va */
    $query = "select AVG(valutazione) AS media_valutazioni FROM recensione where cod_struttura = ".$_REQUEST['cod']. " group by cod_struttura;";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
    if ($result->num_rows > 0 && $result->num_rows != null) {
      $media=round($row["media_valutazioni"], 1);
        echo "<h1 class='valutazione'>★".$media."</h1>";
    }
    /* non va */
    echo "<img src='foto/strutture/".$ret['cod_struttura'].".jpg'>";
    echo "<p class='orario_ris'>orario: ".$ret['orario_apertura'].":00 - ".$ret['orario_chiusura'].":00</p>";
    echo "<a href='recensione.php?cod_struttura=".$_REQUEST["cod"]."' class='recensione'> lascia una recensione </a>";
    echo "<h1 class='menu'>MENU</h1>";
    $query ="select * from menu,contiene where menu.nome_piatto=contiene.nome_piatto and contiene.cod_struttura=".$ret['cod_struttura'];
    $count=0;
    $ris = $conn->query($query);
    while($ret = $ris -> fetch_assoc() ){
      $count++;
      echo "<p class='nome_piatto'>".$ret['nome_Piatto']."</p>";
      echo "<p class='prezzo'>".$ret['prezzo']."</p>";
    }
    if($count==0){
      echo "<p class='err'>Nessun piatto trovato</p>";
    }
?>
<a href=zoo_cliente.php class=back>Back</a>
<body>
