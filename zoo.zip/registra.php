<?php
    session_start();
    $nome = $_REQUEST['nome'];
    $cognome = $_REQUEST['cognome'];
    $data_nascita = strtotime($_REQUEST['nascita']);
    $email = $_REQUEST['email'];
    $pass = md5($_REQUEST['pass']);
    $_SESSION['nome'] = $nome;


    if($data_nascita > time()){
      header("Location:registrazione.php?err=2");
      die();
    }

    $conn = new mysqli("127.0.0.1", "root", "", "Zoo");
    if ($conn->connect_errno) {
        echo $conn->connect_errno;
        die();
    }

    //controllo che non ci siano più utenti con lo stesso nome
    $queryControllo= "Select * from Persona where mail='$email'";
    $ris = $conn->query($queryControllo);
    if($conn->affected_rows == 1) {
        header("Location:registrazione.php?err=1");
        die();
    }

    //inserisco il nuovo utente nel database
    $query = "INSERT INTO Persona (nome, cognome, mail, data_nascita, password) VALUES ('$nome', '$cognome', '$email', '$data_nascita', '$pass');";
    $ris = $conn->query($query);
    if($conn->affected_rows == 1) {
        $_SESSION['user'] = $nome;
        $_SESSION['mail'] = $email;
        $query = "SELECT * FROM persona WHERE mail = '$email' AND password = '$pass';";
        $ris = $conn->query($query);
        while ($row = $ris->fetch_assoc()) {
            $codice = $row['cod_persona'];
        }
        $_SESSION['cod_persona'] = $codice;
        header("Location:zoo_cliente.php");
        die();
    }

    header("Location:login.php?err=2");
    die();

?>
