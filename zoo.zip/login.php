<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <?php
        if (isset($_REQUEST['err'])) {
            switch ($_REQUEST['err']) {
                case '1':
                    echo "<p class=errore>utente non trovato</p>";
                    break;
                default:
                    echo "<p class=errore>errore</p>";
                    break;
            }
        }
    ?>
</head>
<style>
body {
font-family: Arial, sans-serif;
margin: 0;
padding: 0;
background-color: #f8f8f8;
}

.errore{
  text-align: center;
  color: red;
}

h1 {
text-align: center;
margin-top: 40px;
color: #333;
}

form {
width: 300px;
margin: 0 auto;
background-color: #fff;
padding: 20px;
border-radius: 10px;
box-shadow: 0px 0px 10px rgba(0,0,0,0.3);
margin-bottom: 20px;
}

label {
font-size: 16px;
font-weight: bold;
display: block;
margin-bottom: 10px;
}

input[type=email], input[type=password] {
width: 92%;
padding: 10px;
border: 1px solid #ccc;
border-radius: 5px;
margin-bottom: 20px;
}

input[type=submit] {
width: 100%;
background-color: #007bff;
color: #fff;
padding: 10px;
border: none;
border-radius: 5px;
cursor: pointer;
}

a {
display: block;
text-align: center;
margin-top: 20px;
text-decoration: none;
color: #333;
}
</style>
<body>
    <h1>Pagina di Login</h1>
    <form action=autentifica.php method=post>
        <div>
            <label for=email>Inserisci l'email: </label>
            <input type=email name="email" id="email" placeholder="Email" required />
            <label for=password>Inserisci la password: </label>
            <input type=password name="pass" id="pass" placeholder="Password" required />
        </div>
        <div>
            <input type="submit" name="invia" />
        </div>
    </form>
    <center>Non hai un account?</center> <a href=registrazione.php>Registrati ora!</a>
</body>
</html>
