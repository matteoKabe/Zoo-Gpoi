<?php
session_start();
if(!isSet($_SESSION["user"])){
	header("location: login.php?err=2");
	die();
}
if(!isSet($_SESSION["user"])){
	header("location: login.php?err=2");
	die();
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Acquisto biglietti</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<style>

body {
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
}

.costo {
  font-size: 24px;
  font-weight: bold;
  margin: 20px 0;
	text-align: center;
}

.form-container {
  background-color: #fff;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  max-width: 500px;
  margin: 0 auto;
}

label {
  display: block;
  margin-bottom: 10px;
  font-weight: bold;
}

input[type="text"],
input[type="date"],
input[type="number"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 16px;
  box-sizing: border-box;
}

input[type="submit"] {
  background-color: #4CAF50;
  color: #fff;
  border: none;
  border-radius: 5px;
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
}

input[type="submit"]:hover {
  background-color: #3e8e41;
}

.back{
  position: fixed;
  right: 30px;
  text-decoration: none;
  background-color: black;
  color: white;
  padding: 10px 5px;
  border-radius: 5px;
  bottom: 10px;
}

</style>
<body>
  <p class="costo">costo Biglietto : 5€</p>
	<div class="form-container">
		<form method="post" action="processa_acquisto.php">
			<label for="numero_carta">Numero carta di credito:</label>
			<input type="text" id="numero_carta" name="numero_carta" placeholder="0000-0000-0000-0000" required>

			<label for="scadenza">Data di scadenza:</label>
			<input type="date" id="scadenza" name="scadenza" required>

			<label for="cvv">CVV:</label>
			<input type="text" id="cvv" name="cvv" placeholder="000" required>

			<label for="accesso">Data prenotazione:</label>
			<input type="date" id="accesso" name="accesso" required>

			<label for="numero_biglietti">Numero biglietti:</label>
			<input type="number" id="numero_biglietti" name="numero_biglietti" min="1" required>

			<input type="submit" value="Acquista">
			<a href=zoo_cliente.php class=back>Back</a>
		</form>
	</div>
</body>
</html>
