<!DOCTYPE html>
<html>
<head>
	<title>Acquisto biglietti</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<style>
.form-container {
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100vh;
}

form {
	background-color: #f2f2f2;
	padding: 20px;
	border-radius: 5px;
	box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3);
}

label {
	display: block;
	margin-bottom: 10px;
	font-weight: bold;
}

input[type="text"],
input[type="number"],
 input[type="date"]{
	padding: 10px;
	border: none;
	border-radius: 5px;
	margin-bottom: 20px;
	width: 80%;
}

input[type="submit"] {
	background-color: #007bff;
	color: #fff;
	padding: 10px 20px;
	border: none;
	border-radius: 5px;
}

.costo{
  position: absolute;
  font-size: 30px;
  margin-top: 40px;
  margin-left: 42%;
}

</style>
<body>
  <p class="costo">costo Biglietto : 5€</p>
	<div class="form-container">
		<form method="post" action="processa_acquisto.php">
			<label for="numero_carta">Numero carta di credito:</label>
			<input type="text" id="numero_carta" name="numero_carta">

			<label for="scadenza">Data di scadenza:</label>
			<input type="date" id="scadenza" name="scadenza">

			<label for="cvv">CVV:</label>
			<input type="text" id="cvv" name="cvv">

			<label for="numero_biglietti">Numero biglietti:</label>
			<input type="number" id="numero_biglietti" name="numero_biglietti" min="1">

			<input type="submit" value="Acquista">
		</form>
	</div>
</body>
</html>
