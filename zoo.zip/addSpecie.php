<?php
    session_start();
    if(!isSet($_SESSION["user"])){
    	header("location: login.php?err=2");
    	die();
    }
    $nomeSp = $_REQUEST['nome_sp'];
    $fam = $_REQUEST['nomeFam'];

    $conn = new mysqli("127.0.0.1", "root", "", "Zoo");
    if ($conn->connect_errno) {
        echo $conn->connect_errno;
        die();
    }

    //controllo che non ci siano specie con lo stesso nome
    $query = "SELECT * FROM specie WHERE nome_specie = '$nomeSp';";
    $ris = $conn->query($query);
    if($conn->affected_rows == 1){
        header("Location:zooAdmin.php?err=8");
        die();
    }

    //inserisco la nuova specie nel databse
    $query = "INSERT INTO specie (nome_specie,nomeFamiglia) VALUES ('$nomeSp','$fam');";
    $ris = $conn->query($query);

    // aggiungo l'immagine
    $target_dir = "foto/animali/";
  	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
  	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // Verifica se il file è un'immagine
    if($imageFileType != "jpg") {
  	    header("location: zooAdmin.php?err=11");
  	}

    // carica Immagine
    move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);

    header("location: zooAdmin.php?err=9");

?>
