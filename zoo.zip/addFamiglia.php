<?php
    session_start();
    if(!isSet($_SESSION["user"])){
    	header("location: login.php?err=2");
    	die();
    }
    $nomeF = $_REQUEST['nome_f'];

    $conn = new mysqli("127.0.0.1", "root", "", "Zoo");
    if ($conn->connect_errno) {
        echo $conn->connect_errno;
        die();
    }

    //controllo che non ci siano famiglie con lo stesso nome
    $query = "SELECT * FROM famiglia WHERE nomeFamiglia = '$nomeF';";
    $ris = $conn->query($query);
    if($conn->affected_rows == 1){
        header("Location:zooAdmin.php?err=7");
        die();
    }

    //inserisco la nuova famiglia nel databse
    $query = "INSERT INTO famiglia (nomeFamiglia) VALUES ('$nomeF');";
    $ris = $conn->query($query);
    header("location: zooAdmin.php?err=6");
?>
