<?php
session_start();
if(!isSet($_SESSION["user"])){
	header("location: login.php?err=2");
	die();
}
?>
<html>
<head>
	<title>P!nk, il fenicottero rosa</title>
	<style>
		body {
			background-color: #FDEFF3;
			font-family: Arial, sans-serif;
		}
		h1 {
			text-align: center;
			color: #ED1C7F;
			font-size: 80px;
			margin-top: 50px;
			margin-bottom: 50px;
		}
		#pink {
			display: block;
			margin-left: auto;
			margin-right: auto;
			width: 50%;
			max-width: 400px;
			border-radius: 50%;
			border: 5px solid #ED1C7F;
			box-shadow: 0px 0px 20px #ED1C7F;
		}
		p {
			text-align: center;
			margin: 50px;
			line-height: 1.5;
			font-size: 40px;
      color: #ED1C7F;
		}

		.back{
		  position: fixed;
		  right: 30px;
		  text-decoration: none;
		  background-color: black;
		  color: white;
		  padding: 10px 5px;
		  border-radius: 5px;
		  bottom: 10px;
		}
	</style>
</head>
<body>
	<h1>P!nk, il fenicottero rosa</h1>
	<img id="pink" src="foto/pink.jpg" alt="P!nk, il fenicottero rosa">
	<p>Il fenicottero rosa P!nk è un esemplare unico nel suo genere. <br> Con la sua brillante colorazione rosa e il suo lungo collo adattato alla caccia in acqua poco profonda, P!nk è un esempio della meravigliosa diversità del mondo animale. <br> Questo magnifico uccello è stato scoperto per la prima volta in America del Sud, ma ora può essere visto in tutto il mondo, grazie ai tanti parchi zoologici e ai programmi di conservazione che si sono dedicati alla sua protezione.</p>
	<a href=zoo_cliente.php class=back>Back</a>
</body>
</html>
