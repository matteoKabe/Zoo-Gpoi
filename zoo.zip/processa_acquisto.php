<?php
session_start();
if(!isSet($_SESSION["user"])){
	header("location: login.php?err=2");
	die();
}

?>
<!DOCTYPE html>
<html>
  <head>
  	<title>Acquisto effettuato</title>
  	<link rel='stylesheet' type='text/css' href='style.css'>
  	<script>
  		function tornaAllaHome() {
  			window.location.href = 'zoo_cliente.php';
  		}
  	</script>
  </head>
  <style>

    body{
      margin: 50px auto;
      width: 80%;
      max-width: 600px;
      text-align: center;
      border: 20px solid green;
      padding: 20px;
      border-radius: 10px;
    }

    h1 {
    margin-top: 0;
    }

    ul {
    list-style-type: none;
    padding: 0;
    }

    li {
    font-size: 24px;
    margin-bottom: 10px;
    }

    button {
      margin-top: 20px;
      padding: 10px 20px;
      background-color: green;
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 18px;
      cursor: pointer;
    }

    button:hover {
      background-color: darkgreen;
    }

		.err {
		  background-color: #ffcccc;
		  border: 1px solid #ff3333;
		  color: #ff3333;
		  padding: 10px;
		  margin: 10px;
		  border-radius: 5px;
      font-size: 30px;
		}

		a {
		  display: inline-block;
		  margin-top: 10px;
		  padding: 10px;
		  background-color: #ff3333;
		  border: 1px solid #ffcccc;
		  color: #ffcccc;
		  border-radius: 5px;
		  text-decoration: none;
		}

		a:hover {
		  background-color: #ffcccc;
		  color: red;
		}

		.titolo{
			font-size: 30px;
		}


  </style>
  <body>
		<?php
		if(strtotime(date('d-m-Y', strtotime(time())))>strtotime($_REQUEST["accesso"]) || strtotime(date('d-m-Y', strtotime(time())))>strtotime($_REQUEST["scadenza"])){ /* non posso prendere biglietti per il giorno stesso */
			if(time()>strtotime($_REQUEST["accesso"])){
				echo "<p class='err'> non puoi comprare un biglietto per una data passata </p>";
			}else if(time()>strtotime($_REQUEST["scadenza"])){
				echo "<p class='err'> carta scaduta </p>";
			}
			?>
			<a href="compra.php"> riprova </a>
			<?php
		}else{
			$conn = new mysqli("127.0.0.1", "root", "", "zoo") or die("errore");
			$query = "select cod_persona from persona where mail = '".$_SESSION["mail"]."'";
		  $cod_persona = $conn->query($query);
		  $query = "select count(*) from biglietto where data=".strtotime($_REQUEST["accesso"]);
			$cod_persona = $cod_persona->fetch_row()[0];
			$totB = $conn->query($query);
			$totB = $totB->fetch_row()[0];
			if($totB + $_REQUEST["numero_biglietti"] <= 500){	// 500 numero messo di default
				for($i=0; $i<$_REQUEST["numero_biglietti"]; $i++){
					$query = "insert into biglietto (cod_persona, data) value ('".$cod_persona."',".strtotime($_REQUEST["accesso"]).")";
				  $ris = $conn->query($query);
				}
			}
		?>
  	<div class='successo'>
  		<h1>Acquisto effettuato con successo</h1>
  		<p class="titolo">I codici dei biglietti:</p>
  		<ul><?php
					$query = "SELECT cod_biglietto FROM Biglietto ORDER BY cod_biglietto DESC LIMIT ".$_REQUEST["numero_biglietti"];
					$result = $conn->query($query);

					// Stampa dei risultati
					if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
							echo "<li>".$row["cod_biglietto"] . "</li><br>";
					}
					} else {
					echo "<li>Nessun risultato.</li>";
					}
        ?>
      </ul>
  		<button onclick='tornaAllaHome()'>Torna alla home</button>
      <p>Mi raccomando non scordarteli</p>
  	</div>
		<?php
		}
		?>
  </body>
</html>
