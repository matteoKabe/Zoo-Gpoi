<?php
$num_biglietti = $_POST['numero_biglietti'];

// Genera un array di codici casuali
$codici = array();
for ($i = 0; $i < $num_biglietti; $i++) {
	$codici[] = rand(10000, 99999);
}

?>
<!DOCTYPE html>
<html>
  <head>
  	<title>Acquisto effettuato</title>
  	<link rel='stylesheet' type='text/css' href='style.css'>
  	<script>
  		function tornaAllaHome() {
  			window.location.href = 'zoo_cliente.php';
  		}
  	</script>
  </head>
  <style>
    body{
      margin: 50px auto;
      width: 80%;
      max-width: 600px;
      text-align: center;
      border: 20px solid green;
      padding: 20px;
      border-radius: 10px;
    }

    h1 {
    margin-top: 0;
    }

    ul {
    list-style-type: none;
    padding: 0;
    }

    li {
    font-size: 24px;
    margin-bottom: 10px;
    }

    button {
      margin-top: 20px;
      padding: 10px 20px;
      background-color: green;
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 18px;
      cursor: pointer;
    }

    button:hover {
      background-color: darkgreen;
    }
  </style>
  <body>
  	<div class='successo'>
  		<h1>Acquisto effettuato con successo</h1>
  		<p>I codici dei biglietti:</p>
  		<ul><?php
        foreach ($codici as $codice) {
        	echo "<li>$codice</li>";
        }?>
      </ul>
  		<button onclick='tornaAllaHome()'>Torna alla home</button>
      <p>Mi raccomando non scordarteli</p>
  	</div>
  </body>
</html>
