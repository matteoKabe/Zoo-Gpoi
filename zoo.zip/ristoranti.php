<?php
session_start();
if(!isSet($_SESSION["user"])){
	header("location: login.php?err=2");
	die();
}
?>
<style>

body{
  font-family: Arial, sans-serif;
  background-color: tan;
  text-align: center;
  text-transform: capitalize;
  margin-top: 50px;
}

.titolo{
  font-size: 100px;
  font-weight: bold;
}

a{
  text-decoration: none;
}

table {
    background-color: sienna;
    width: 80%;
    display: block;
    margin-top: 30px;
    padding: 5px;
    margin-left: 10%;
  }

  img {
		width: 300px;
		height: 300px;
    padding: 5%;
    display: block;
    margin: 0 auto;
  }

  .immagine {
    width: 30%;
    text-align: center;
  }

.nome_rist{
  font-size: 60px;
  font-weight: bold;
  margin-left: 60px;
}

.orario_ris{
  font-size: 40px;
  margin-left: 60px;
}

.err{
  color: red;
  font-size: 100px;
  font-weight: bold;
}

.back{
  position: fixed;
  right: 30px;
  text-decoration: none;
  background-color: black;
  color: white;
  padding: 10px 5px;
  border-radius: 5px;
  bottom: 10px;
}

</style>

<body>
<h1 class="titolo"> ristoranti ZOO 105 </h1>
<?php
    $conn  = new  mysqli("127.0.0.1","root","","zoo")or die("errore");
    //da errore quando non  trova un utente
    $query ="select * from ristoranti";
    $count=0;
    $ris = $conn->query($query);
    while($ret = $ris -> fetch_assoc() ){
      $count++;
      echo "<a href='ristorante.php?cod=".$ret['cod_struttura']."'>";
      echo "<table>";
      echo "<th>";
      echo "<td class='immagine'><img src='foto/strutture/".$ret['cod_struttura'].".jpg'></td>";
      echo "<td class='dati'><p class='nome_rist'>".$ret['nome_ristorante']."</p>";
      echo "<p class='orario_ris'> orario: ".$ret['orario_apertura'].":00 - ".$ret['orario_chiusura'].":00</p></td>";
      echo "<th>";
      echo "</table>";
      echo "</a>";
    }
    if($count==0){
      echo "<p class='err'>Nessun ristorante trovato</p>";
    }
?>
<a href=zoo_cliente.php class=back>Back</a>
<body>
