<body>
animali per razza <?php echo $_REQUEST["razza"]; ?>
<body>
