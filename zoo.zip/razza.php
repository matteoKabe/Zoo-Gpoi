<?php
session_start();
if(!isSet($_SESSION["user"])){
	header("location: login.php?err=2");
	die();
}
// Connessione al database
$conn  = new  mysqli("127.0.0.1","root","","zoo")or die("errore");

// Ottenere la lista degli animali
$query= "select * from ProfiloAnimale, specie where specie.cod_specie = ProfiloAnimale.cod_specie and Specie.nome_specie like '".$_REQUEST["razza"]."%'";

if(isset($_REQUEST["orderBy"])) {
    $orderBy = $_REQUEST["orderBy"];
    switch($orderBy) {
        case "musica":
            $query .= " order by ProfiloAnimale.musica";
            break;
        case "eta":
            $query .= " order by ProfiloAnimale.eta_animale";
            break;
        case "peso":
            $query .= " order by ProfiloAnimale.peso";
            break;
        case "nome":
            $query .= " order by ProfiloAnimale.nome";
            break;
    }
}

$animals = $conn->query($query);


// ottenere la lista degli animali animaliSeguiti
$query= "select * from Utenti where cod_persona = ". $_SESSION["cod_persona"].";";
$ris = $conn->query($query);
while($ret = $ris -> fetch_assoc() ){
  $animaliSeguiti[]= $ret["animaliSeguiti"];
}

//segui e non segui animale
if(isSet($_POST["animalName"])){
  if(isset($_REQUEST["follow"])){
    if(!isSet($animaliSeguiti) || !in_array($_POST["animalName"], $animaliSeguiti)){
       $animalName = $_POST["animalName"];
       $query = "insert INTO Utenti (cod_persona, animaliSeguiti) VALUES (".$_SESSION["cod_persona"].", '".$animalName."')";
       $conn->query($query);
       echo "<script>window.location.reload();</script>";
    }
  }

  if(isset($_REQUEST["unfollow"]) && isSet($animaliSeguiti)){
    if(in_array($_POST["animalName"], $animaliSeguiti)){
       $animalName = $_POST["animalName"];
       $query = "delete FROM Utenti WHERE cod_persona = ".$_SESSION["cod_persona"]." and animaliSeguiti = '".$animalName."'";
       $conn->query($query);
       echo "<script>window.location.reload();</script>";
    }
  }
}


?>

<!DOCTYPE html>
<html>
<head>
    <title>Lista animali</title>
</head>
<body>
    <h1>Lista animali</h1>
    <?php
    $query1= "select nomeFamiglia from specie where specie.nome_specie = '". $_REQUEST["razza"]."';";
    $ris1 = $conn->query($query1);
    $ris1 = $ris1->fetch_assoc();
    echo "<p class=presentazione>".$_REQUEST["razza"]." della famiglia ". $ris1["nomeFamiglia"]."</p>";
    ?>
    <center>
    <form method="get" class="ordinamento">
        <input type="hidden" name="razza" value="<?php echo $_REQUEST["razza"];?>">
        <select name="orderBy">
            <option value="musica">Musica</option>
            <option value="eta">Età</option>
            <option value="peso">Peso</option>
            <option value="nome">Nome</option>
        </select>
        <input type="submit" name="Ordina" value="Ordina" id="Ordina">
    </form>
  </center>
	<table>
		<tr>
			<th>Nome</th>
			<th>Specie</th>
			<th>Età</th>
			<th>Peso</th>
			<th>Musica</th>
      <th>libertà</th>
      <th>coordinate</th>
      <th>data arrivo</th>
			<th></th>
		</tr>
    <?php
    if(mysqli_num_rows($animals) == 0){ // se non trovs nessun animale
      echo "<p class='err'>nessun profilo trovato</p>";
    }
    ?>
		<?php foreach($animals as $row){ ?>
		<tr>
			<td><?php echo $row["nome"]; ?></td>
			<td><?php echo $row["nome_specie"]; ?></td>
			<td><?php echo $row["eta_animale"]; ?></td>
			<td><?php echo $row["peso"]; ?></td>
			<td><?php echo $row["musica"]; ?></td>
      <?php
      $query= "select * from liberta where nome_animale = '". $row["nome"]."';";
      $ris = $conn->query($query);
      $ris = $ris->fetch_assoc();
      ?>
      <td><?php if($ris == null){ echo "cresciuto in cattività";}else{echo "era in libertà";} ?></td>
      <td><?php if($ris == null){ echo " - ";}else{echo $ris["coordinate"];} ?></td>
      <td><?php if($ris == null){ echo " - ";}else{echo $ris["dataArrivo"];} ?></td>
			<td>
				<form method="post">
					<input type="hidden" name="animalName" value="<?php echo $row["nome"]; ?>">
					<?php if(isset($animaliSeguiti) && in_array($row["nome"], $animaliSeguiti)){ /* dice se il nome si trova nell'array animali seguiti */?>
					<input type="submit" name="unfollow" value="unfollow" id="unfollow">
        <?php }else{ ?>
					<input type="submit" name="follow" value="follow" id="follow">
        <?php } ?>
				</form>
			</td>
		</tr>
  <?php } ?>
	</table>
  <a href=zoo_cliente.php class=back>Back</a>
</body>

<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f2f2f2;
    text-transform: capitalize;
  }

  .presentazione{
    text-align: center;
  }

  .ordinamento{
    margin-bottom: 30px;
  }

  .err{
    color: red;
    font-size: 20px;
    text-align: center;
    font-weight: bold;
  }

  h1 {
    text-align: center;
  }

  table {
    border-collapse: collapse;
    margin: 0 auto;
  }

  th,
  td {
    padding: 10px;
    text-align: center;
  }

  th {
    background-color: violet;
    font-weight: bold;
  }

  tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  input[type=submit] {
    background-color: violet;
    color: white;
    border: none;
    padding: 3px 16px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 14px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 8px;
  }

  select, option {
    font-size: 14px;
    padding: 4px;
    border-radius: 8px;
  }

  .back{
    position: fixed;
    right: 30px;
    text-decoration: none;
    background-color: black;
    color: white;
    padding: 10px 5px;
    border-radius: 5px;
    bottom: 10px;
  }

  </style>
</html>
