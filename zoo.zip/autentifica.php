<?php
    session_start();

    $email = $_REQUEST['email'];
    $password = md5($_REQUEST['pass']);

    $conn = new mysqli("127.0.0.1", "root", "", "Zoo");
    if ($conn->connect_errno) {
        echo $conn->connect_errno;
        die();
    }

    //login per l'admin
    if($email == "admin@gmail.com" && $password == "21232f297a57a5a743894a0e4a801fc3"){
        $_SESSION["user"]="admin";
        header("location:zooAdmin.php");
        die();
    }

    //login per i dipendenti
    //dato che i dipendenti sono gli unici ad avere l'attributo "nomignolo" allora se avrò una riga che risponde alla mia query
    //vuol dire che avrò trovato un lavoratore
    $query = "select Nomignolo FROM Dipendenti, Persona WHERE Dipendenti.cod_persona = Persona.cod_persona AND mail='$email' AND password='$password';";
    $ris = $conn->query($query);
    if ($ris->num_rows > 0) {
        $riga = $ris->fetch_assoc();
        $_SESSION['Nomignolo'] = $riga['Nomignolo'];
        header("location:zooDipendenti.php");
        die();
    }

    //login per i clienti
    $query = "SELECT * FROM Persona WHERE mail='$email' AND password='$password'";
    $ris = $conn->query($query);
    if ($conn->affected_rows == 1) {
        $query = "SELECT * FROM persona WHERE mail = '$email' AND password = '$password';";
        $ris = $conn->query($query);
        while ($row = $ris->fetch_assoc()) {
            $codice = $row['cod_persona'];
            $nome = $row['nome'];
            $mail = $row['mail'];
        }
        $_SESSION['user'] = $nome;
        $_SESSION['mail'] = $mail;
        $_SESSION['cod_persona'] = $codice;
        var_dump($row);
        var_dump($_SESSION);
        header("location:zoo_cliente.php");
        die();
    }

    header("location:login.php?err=1");

?>
