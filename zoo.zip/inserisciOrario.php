<?php
    session_start();
    if(!isSet($_SESSION["Nomignolo"])){
    	header("location: login.php?err=2");
    	die();
    }
?>
<body>
  <p class="warning"> !! PAGINA ANCORA IN COSTRUZIONE !!</p>
  <a href=login.php class="back">Back</a>
</body>
<style>
  .back{
    position: fixed;
    right: 30px;
    text-decoration: none;
    background-color: black;
    color: white;
    padding: 10px 5px;
    border-radius: 5px;
    bottom: 10px;
  }

  .warning {
    color: red;
    font-weight: bold;
    font-size: 24px;
    text-align: center;
    margin-top: 50px;
  }
</style>
