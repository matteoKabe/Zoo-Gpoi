<?php
session_start();
if(!isSet($_SESSION["user"])){
	header("location: login.php?err=2");
	die();
}
?>
<style>

body{
  font-family: Arial, sans-serif;
  background-color: deepskyblue;
  text-align: center;
  margin-top: 50px;
}

.titolo{
  font-size: 100px;
  font-weight: bold;
}

a{
  text-decoration: none;
}

table {
    background-color: sienna;
    width: 100%;
    display: block;
    margin-top: 30px;
    padding: 5px;
    width: 80%;
    margin-left: 10%;
  }

  img {
    padding: 5%;
    display: block;
    margin: 0 auto;
		width: 300px;
		height: 300px;
  }

  .immagine {
    width: 30%;
    text-align: center;
  }

.nome_neg{
  font-size: 60px;
  font-weight: bold;
  margin-left: 60px;
}

.orario_neg{
  font-size: 40px;
  margin-left: 60px;
}

.amazon{
  background-color: black;
  color: white;
  padding: 50px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  border-style: double;
  margin-top: 50px;
  width: 40%;
  font-size: 50px;
  border-radius: 50px;
}

.amazon:hover{
  background-color: white;
  color: black;
  transition: 0.5s;
}

.err{
  color: red;
  font-size: 100px;
  font-weight: bold;
}

.back{
  position: fixed;
  right: 30px;
  text-decoration: none;
  background-color: black;
  color: white;
  padding: 10px 5px;
  border-radius: 5px;
  bottom: 10px;
}

</style>

<body>
  <h1 class="titolo"> Negozi ZOO 105 </h1>
  <?php
      $conn  = new  mysqli("127.0.0.1","root","","zoo")or die("errore");
      //da errore quando non  trova un utente
      $query ="select * from NegozioGiocattoli";
      $count=0;
      $ris = $conn->query($query);
      while($ret = $ris -> fetch_assoc() ){
        $count++;
        echo "<table>";
        echo "<th>";
        echo "<td class='immagine'><img src='foto/strutture/".$ret['cod_struttura'].".jpg'></td>";
        echo "<td class='dati'><p class='nome_neg'>".$ret['nome_negozio']."</p>";
        echo "<p class='orario_neg'> orario: ".$ret['orario_apertura'].":00 - ".$ret['orario_chiusura'].":00</p></td>";
        echo "</table>";
      }
      if($count==0){
        echo "<p class='err'>Nessun negozio trovato</p>";
      }
  ?>
  </br>
  <a href="https://www.amazon.it/s?k=pupazzi+animali+dello+zoo&__mk_it_IT=%C3%85M%C3%85%C5%BD%C3%95%C3%91&crid=1JY7ULGFUX1K4&sprefix=pupazzi+animali+dello+zoo%2Caps%2C150&ref=nb_sb_noss" class=amazon target="plank"> Acquista Dei Giochi </a>
  <a href=zoo_cliente.php class=back>Back</a>

<body>
