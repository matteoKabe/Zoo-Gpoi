<?php
    session_start();
    if(!isSet($_SESSION["Nomignolo"])){
    	header("location: login.php?err=2");
    	die();
    }
?>

<head>
    <?php
        $nomignolo = $_SESSION['Nomignolo'];

        $conn = new mysqli("127.0.0.1", "root", "", "Zoo");
        if ($conn->connect_errno) {
             echo $conn->connect_errno;
             die();
        }

        $query = "SELECT orario_lavorativo FROM Dipendenti WHERE nomignolo='$nomignolo'";
        $ris = $conn->query($query);
        if ($conn->affected_rows == 1) {
            $riga = $ris->fetch_assoc();
            $ore = $riga['orario_lavorativo'];
        }

    ?>
</head>
<body>
    <h1>Benvenuto <?php echo $nomignolo; ?> </h1>
    <h3>Queste sono le tue ore settimanali: <?php if(isSet($ore)){echo $ore;}else{echo 0;} ?> </h3>
    <label for=turni>Inserisci l'orario di inizio e di fine turno</label>
    <form id=turni action=inserisciOrario.php method=post>
        <input type=number name=inizio placeholder="Inizio turno" required />
        <input type=number name=fine placeholder="Fine turno" required />
        <input type=submit name=invia/>
    </form>
    <a href=login.php>Torna alla pagina di Login</a>
</body>
<style>
body {
    background-color: #f5f5f5;
    font-family: Arial, sans-serif;
    font-size: 16px;
    color: #333;
    line-height: 1.5;
}

h1 {
    font-size: 32px;
    color: #333;
    margin-bottom: 20px;
}

h3 {
    font-size: 20px;
    color: #666;
    margin-bottom: 10px;
}

label {
    font-size: 16px;
    color: #666;
    margin-bottom: 10px;
    display: block;
}

input[type="number"] {
    font-size: 16px;
    color: #333;
    padding: 10px;
    border-radius: 5px;
    border: none;
    box-shadow: 1px 1px 1px rgba(0, 0, 0, 0.1);
    margin-bottom: 10px;
}

input[type="submit"] {
    background-color: #333;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

a {
    color: #666;
    text-decoration: none;
}

a:hover {
    color: #333;
}

</style>
